# Portfolio ![python License](https://img.shields.io/badge/MADE%20WITH-ReactJS-blue.svg)

A simple portfolio which describe about myself, build with using ReactJS, Tailwind CSS and framer motion

live Link: https://react-portfolio-4ubw5qv2q-rahulkumar7983.vercel.app/

<img width="947" alt="react-portfolio-image" src="https://user-images.githubusercontent.com/120224923/224770229-1c7979e7-160b-45f5-867f-4d6c1e9bf70e.png">

### Technologies used:
* HTML
* CSS
* JavaScript/jQuery 3.1.1
* React
* Tailwind CSS
* Framer-motion

### ThankYou!
